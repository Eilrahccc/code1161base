# create_db.py
import sqlite3

conn = sqlite3.connect('mydb.db')
c = conn.cursor()


c.execute('''DROP TABLE IF EXISTS weather''')
c.execute('''CREATE TABLE weather (month text, evaporationc text, evaporationa text)''')
c.execute('''DROP TABLE IF EXISTS weather1''')
c.execute('''CREATE TABLE weather1 (month text, precipitationc text, precipitationa text)''')


purchases = [('Jan', 59, 168.4),
             ('Feb', 62.4, 149.8),
             ('Mar', 98.4, 115.6),
             ('Apr', 103.5, 80.7),
             ('May', 120, 71.4),
             ('June', 146.5, 56.4),
             ('July', 142.4, 50.2),
             ('Aug', 116, 72.9),
             ('Sept', 100.6, 80),
             ('Oct', 72.5, 103.2),
             ('Nov', 60.2, 110),
             ('Dec', 36.8, 124.9)
            ]

purchases1 = [('Jan', 63.5, 75.05),
             ('Feb', 82.4, 44.57),
             ('Mar', 157.6, 66.46),
             ('Apr', 203.8, 10.68),
             ('May', 210.4, 46.34),
             ('June', 209.7, 52.05),
             ('July', 130.5, 36.59),
             ('Aug', 120, 28.49),
             ('Sept', 98.4, 49.15),
             ('Oct', 78, 20.17),
             ('Nov', 56.9, 23.69),
             ('Dec', 35, 91.75)
            ]

c.executemany('INSERT INTO weather VALUES (?,?,?)', purchases)
c.executemany('INSERT INTO weather1 VALUES (?,?,?)', purchases1)


conn.commit()


for row in c.execute('SELECT * FROM weather'):
    print(row)
        
c.execute('SELECT * FROM weather')
print(c.fetchall())


res = c.execute('SELECT * FROM weather')
print(res.fetchall())

for row1 in c.execute('SELECT * FROM weather1'):
    print(row1)
        
c.execute('SELECT * FROM weather1')
print(c.fetchall())


res1 = c.execute('SELECT * FROM weather1')
print(res1.fetchall())

conn.close()